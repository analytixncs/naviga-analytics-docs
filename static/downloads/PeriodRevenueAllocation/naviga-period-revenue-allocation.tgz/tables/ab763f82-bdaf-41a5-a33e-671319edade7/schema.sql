CREATE TABLE "sample_upload" ( "column_one" text  , "column_two" text  , "_imported" timestamp with time zone  , "_rowIndex" bigint  NOT NULL );
CREATE TABLE "sdl_dates" ( "date" date  , "_imported" timestamp with time zone  , "_rowIndex" bigint  NOT NULL );
CREATE TABLE "financial_period_spreads" ( "period" text  , "quarter" integer  , "days_in_period" integer  , "start" date  , "end" date  , "outerjoin" integer  , "_imported" timestamp with time zone  , "_rowIndex" bigint  NOT NULL );
CREATE SEQUENCE IF NOT EXISTS "sample_upload__rowIndex_seq" AS bigint INCREMENT BY 1 MINVALUE 1 START WITH 1;
CREATE SEQUENCE IF NOT EXISTS "sdl_dates__rowIndex_seq" AS bigint INCREMENT BY 1 MINVALUE 1 START WITH 1;
CREATE SEQUENCE IF NOT EXISTS "financial_period_spreads__rowIndex_seq" AS bigint INCREMENT BY 1 MINVALUE 1 START WITH 1;
